# Opportunist

The online Opportunist application allows job seekers and recruiters to connect.The application provides the ability for job seekers to create their accounts, upload their profile and resume, search for jobs, apply for jobs, view different job openings. The application provides the ability for companies to create their accounts, search candidates, create job postings, and view candidates applications.

# View Tutorials

Opportunist (PHP) - Part 1 - Introduction & User Login/Registration - https://youtu.be/3VGxEEpWEaw

Opportunist (PHP) - Part 2 - User Dashboard & Profile Updating - https://youtu.be/VkKXaqFafRA

Opportunist (PHP) - Part-3 - Company Login/Registration & Creating Job Posts - https://youtu.be/OiapxMhgH_I

Opportunist (PHP) - Part 4 - View/Edit/Delete Job Posts - https://youtu.be/E1F-snEgpPs

Opportunist (PHP) - Part 5 - Showing Random Job Post On Homepage & User Applying To Job - https://youtu.be/3qmjqLx3o6o

Opportunist (PHP) - Part 6 - Code Refactor & Bug Fix - https://youtu.be/YVv_JCcVb7s

Opportunist (PHP) - Part 7 - Job Search Page With Advanced Searching Options  - https://youtu.be/wgNd-HgxqJg

Opportunist (PHP) - Part 8 - Generating Resume By Filling Form Using Custom Resume Templates - https://youtu.be/Wndjgmk1SyM

Opportunist (PHP) - Part 9 - Uploading Resume & Company View/Reject User Application - https://youtu.be/SMjiO0UwAoA

Opportunist (PHP) - Part 10 - Admin Panel - https://youtu.be/UdLpBUR2lCs

Opportunist (PHP) - Part 11 - Admin Verifying Company & User Email Verification - https://youtu.be/RwybCIHj0JE

Opportunist (PHP) - Part 12 - Validations & Code Improvements - https://youtu.be/mpO1j16udzM

Opportunist (PHP) - Part 13 - Email Sending Bug Fix - https://youtu.be/5ONR88bt0bY

Opportunist (PHP) - Part 14 - Search Highlighting & Forgot Password - https://youtu.be/HR7tvK5oO1g

Opportunist (PHP) - Part 15 - Select Company Location & Fixed Experience Filter - https://youtu.be/0mDXlpOulWc

Opportunist (PHP) - Part 16 - Theme Update Introduction - https://youtu.be/Lm5I6SSgJAw

Opportunist (PHP) - Part 17 - Homepage, Login & Registration Updated To New Theme - https://youtu.be/6neTJ6QRH6U

Opportunist (PHP) - Part 18 - Company Registration & Login Updated To New Theme - https://youtu.be/WJrQTybFQxo

Opportunist (PHP) - Part 19 - Updated Create Job Post & View Company Job Post - https://youtu.be/PK3Q9aAba-0


Copyrights by Gullapudi Veekshith(20190353), Siddeshwar(20190609), Yashwanth Chandra()
Web Development
Montreal College of Information Technology


